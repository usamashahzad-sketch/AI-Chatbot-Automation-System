All details provided in README.md on the Homepage and Comments are Available in the Codebase.
